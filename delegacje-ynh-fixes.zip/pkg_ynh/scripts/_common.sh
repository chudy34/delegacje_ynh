#!/bin/bash
# Common variables for Delegacje SaaS YunoHost scripts

app=$YNH_APP_INSTANCE_NAME

install_dir=$(ynh_app_setting_get --app="$app" --key="install_dir")
data_dir=$(ynh_app_setting_get --app="$app" --key="data_dir")

domain=$(ynh_app_setting_get --app="$app" --key="domain")
path=$(ynh_app_setting_get --app="$app" --key="path")
path=${path%/}

port_backend=$(ynh_app_setting_get --app="$app" --key="port_backend")
port_frontend=$(ynh_app_setting_get --app="$app" --key="port_frontend")

db_pwd=$(ynh_app_setting_get --app="$app" --key="db_pwd")

ai_provider=$(ynh_app_setting_get --app="$app" --key="ai_provider")
gemini_api_key=$(ynh_app_setting_get --app="$app" --key="gemini_api_key")

jwt_secret=$(ynh_app_setting_get --app="$app" --key="jwt_secret")
encryption_key=$(ynh_app_setting_get --app="$app" --key="encryption_key")
